document.addEventListener('DOMContentLoaded', function() {
  const replaceButton = document.getElementById('replaceButton');
  const replaceTextElement = document.getElementById('replaceText');
  let isReplacing = false;

  // Load saved text from storage
  chrome.storage.local.get(['replacementText'], function(result) {
    if (result.replacementText) {
      replaceTextElement.value = result.replacementText;
    }
  });

  replaceButton.addEventListener('click', function() {
    const replaceText = replaceTextElement.value;

    if (!isReplacing) {
      // Send message to background script to start replacing
      chrome.runtime.sendMessage({ action: 'startReplacing', text: replaceText }, function(response) {
        console.log(response.message); // Optional: Log response from background script
      });

      replaceButton.textContent = 'Stop Replacing Text';
      replaceButton.classList.remove('startButton');
      replaceButton.classList.add('stopButton');
      isReplacing = true;
    } else {
      // Send message to background script to stop replacing
      chrome.runtime.sendMessage({ action: 'stopReplacing' }, function(response) {
        console.log(response.message); // Optional: Log response from background script
      });

      replaceButton.textContent = 'Start Replacing Text';
      replaceButton.classList.remove('stopButton');
      replaceButton.classList.add('startButton');
      isReplacing = false;

      // Reload the active tab
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        chrome.tabs.reload(tabs[0].id);
      });
    }

    // Save text to storage
    chrome.storage.local.set({ 'replacementText': replaceText });
  });
});
