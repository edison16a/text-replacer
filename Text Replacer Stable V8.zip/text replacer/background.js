let isReplacing = false;
let intervalId = null;
let replacementText = '';

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === 'startReplacing' && !isReplacing) {
    isReplacing = true;
    replacementText = message.text;

    // Start replacing text every second
    intervalId = setInterval(function() {
      chrome.tabs.query({}, function(tabs) {
        tabs.forEach(function(tab) {
          chrome.tabs.executeScript(tab.id, {
            code: `
              const elements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, a, li, td, th, strong, em, b, i, u, blockquote, q');
              elements.forEach(element => {
                element.textContent = "${replacementText}";
              });
            `
          });
        });
      });
    }, 1000); // Replace text every second

    sendResponse({ message: 'Text replacement started.' });
  } else if (message.action === 'stopReplacing' && isReplacing) {
    clearInterval(intervalId);
    isReplacing = false;
    replacementText = '';
    sendResponse({ message: 'Text replacement stopped.' });
  }
  
  // Keep the message channel open for async response
  return true;
});
