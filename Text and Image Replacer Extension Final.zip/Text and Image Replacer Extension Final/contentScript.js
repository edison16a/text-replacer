let currentSettings = null;
let observer = null;

function isEditable(el) {
  return el.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName);
}

function shouldPreserveNode(node) {
  if (!currentSettings) return true;
  if (currentSettings.preserveInputs && isEditable(node)) return true;
  if (currentSettings.preserveLinks && node.closest && node.closest("a")) return true;
  return false;
}

function replaceTextOnPage() {
  if (!currentSettings || (currentSettings.mode !== "text" && currentSettings.mode !== "both")) return;
  const replacement = currentSettings.replacementText ?? "";

  const elements = document.querySelectorAll(
    "h1,h2,h3,h4,h5,h6,p,li,td,th,strong,span,em,b,i,u,blockquote,q,label,figcaption,button"
  );

  elements.forEach(el => {
    if (shouldPreserveNode(el)) return;
    el.textContent = replacement;
  });

  // Also replace bare text nodes in typical containers
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
  let node;
  while ((node = walker.nextNode())) {
    if (!node.parentElement || shouldPreserveNode(node.parentElement)) continue;
    if (node.nodeValue && node.nodeValue.trim().length > 0) {
      node.nodeValue = replacement;
    }
  }
}

function replaceImagesOnPage() {
  if (!currentSettings || (currentSettings.mode !== "images" && currentSettings.mode !== "both")) return;
  const url = currentSettings.imageUrl || "";
  if (!url) return;

  document.querySelectorAll("img").forEach(img => {
    img.src = url;
    img.srcset = url;
    img.style.objectFit = currentSettings.imageFit || "cover";
  });

  // background images
  document.querySelectorAll("*").forEach(el => {
    const bg = getComputedStyle(el).backgroundImage;
    if (bg && bg !== "none") {
      el.style.backgroundImage = `url("${url}")`;
      el.style.backgroundSize = currentSettings.imageFit === "contain" ? "contain" : "cover";
      el.style.backgroundPosition = "center";
      el.style.backgroundRepeat = "no-repeat";
    }
  });
}

function applyAll() {
  replaceTextOnPage();
  replaceImagesOnPage();
}

function startObserver() {
  if (!currentSettings?.observerEnabled) return;
  if (observer) observer.disconnect();

  observer = new MutationObserver(() => {
    applyAll();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });
}

function stopAll() {
  if (observer) observer.disconnect();
  observer = null;
  currentSettings = null;
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "stateUpdate") {
    currentSettings = msg.settings;
    applyAll();
    startObserver();
  }
  if (msg.action === "stop") {
    stopAll();
    window.location.reload();
  }
});
