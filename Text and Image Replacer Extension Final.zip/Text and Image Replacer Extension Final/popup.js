const DEFAULTS = {
  enabled: false,
  mode: "both",
  replacementText: "",
  imageUrl: "",
  perSite: {}
};

function getHost(url) {
  try { return new URL(url).hostname; } catch { return ""; }
}

document.addEventListener("DOMContentLoaded", async () => {
  const replacementTextEl = document.getElementById("replacementText");
  const segBtns = [...document.querySelectorAll(".segBtn")];
  const imageUploadEl = document.getElementById("imageUpload");
  const previewWrap = document.getElementById("previewWrap");
  const previewImg = document.getElementById("previewImg");
  const clearImageBtn = document.getElementById("clearImage");
  const toggleBtn = document.getElementById("toggleBtn");
  const siteBtn = document.getElementById("siteBtn");
  const badge = document.getElementById("statusBadge");
  const openSettingsBtn = document.getElementById("openSettings");
  const uploadSub = document.getElementById("uploadSub");

  // Load settings
  const { settings } = await chrome.runtime.sendMessage({ action: "getSettings" });
  const merged = { ...DEFAULTS, ...settings };

  replacementTextEl.value = merged.replacementText || "";
  setModeUI(merged.mode);
  setEnabledUI(merged.enabled);

  if (merged.imageUrl) {
    previewImg.src = merged.imageUrl;
    previewWrap.classList.remove("hidden");
    uploadSub.textContent = "Image uploaded";
  }

  // Per-site button label
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const host = getHost(tab?.url || "");
  const overridden = host && merged.perSite && (host in merged.perSite);
  const perSiteEnabled = overridden ? merged.perSite[host] : merged.enabled;
  siteBtn.textContent = perSiteEnabled ? "Disable on this site" : "Enable on this site";

  // Save text live
  replacementTextEl.addEventListener("input", () => {
    chrome.storage.local.set({ replacementText: replacementTextEl.value });
    if (merged.enabled) pushStart();
  });

  // Mode buttons
  segBtns.forEach(btn => {
    btn.addEventListener("click", async () => {
      segBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      merged.mode = btn.dataset.mode;
      await chrome.storage.local.set({ mode: merged.mode });
      if (merged.enabled) pushStart();
    });
  });

  // Image upload
  imageUploadEl.addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      merged.imageUrl = reader.result;
      await chrome.storage.local.set({ imageUrl: merged.imageUrl });
      previewImg.src = merged.imageUrl;
      previewWrap.classList.remove("hidden");
      uploadSub.textContent = "Image uploaded";
      if (merged.enabled) pushStart();
    };
    reader.readAsDataURL(file);
  });

  clearImageBtn.addEventListener("click", async () => {
    merged.imageUrl = "";
    await chrome.storage.local.set({ imageUrl: "" });
    previewWrap.classList.add("hidden");
    uploadSub.textContent = "PNG/JPG/WebP";
    if (merged.enabled) pushStart();
  });

  // Toggle global enable
  toggleBtn.addEventListener("click", async () => {
    merged.enabled = !merged.enabled;
    if (merged.enabled) {
      await chrome.runtime.sendMessage({
        action: "start",
        replacementText: replacementTextEl.value,
        imageUrl: merged.imageUrl,
        mode: merged.mode
      });
    } else {
      await chrome.runtime.sendMessage({ action: "stop" });
    }
    setEnabledUI(merged.enabled);
  });

  // Toggle per-site
  siteBtn.addEventListener("click", async () => {
    const value = !perSiteEnabled;
    await chrome.runtime.sendMessage({ action: "setPerSite", value });
    siteBtn.textContent = value ? "Disable on this site" : "Enable on this site";
  });

  openSettingsBtn.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  function pushStart() {
    chrome.runtime.sendMessage({
      action: "start",
      replacementText: replacementTextEl.value,
      imageUrl: merged.imageUrl,
      mode: merged.mode
    });
  }

  function setModeUI(mode) {
    segBtns.forEach(b => b.classList.toggle("active", b.dataset.mode === mode));
  }

  function setEnabledUI(enabled) {
    badge.textContent = enabled ? "On" : "Off";
    badge.classList.toggle("on", enabled);
    toggleBtn.textContent = enabled ? "Disable" : "Enable";
    toggleBtn.classList.toggle("off", !enabled);
  }
});
