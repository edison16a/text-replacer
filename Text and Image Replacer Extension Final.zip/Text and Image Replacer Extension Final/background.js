const DEFAULTS = {
  enabled: false,
  mode: "both", // "text" | "images" | "both"
  replacementText: "REPLACED",
  imageUrl: "",
  observerEnabled: true,
  preserveInputs: true,
  preserveLinks: true,
  imageFit: "cover", // "cover" | "contain" | "fill"
  whitelist: [],
  blacklist: [],
  perSite: {} // { "example.com": true/false }
};

async function getSettings() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

function getHostname(url) {
  try { return new URL(url).hostname; } catch { return ""; }
}

async function shouldRunOnTab(tab) {
  const settings = await getSettings();
  const host = getHostname(tab.url || "");

  if (!tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://")) {
    return false;
  }

  // blacklist wins
  if (settings.blacklist.some(d => host === d || host.endsWith("." + d))) return false;

  // if whitelist has entries, only run on those
  if (settings.whitelist.length > 0) {
    const ok = settings.whitelist.some(d => host === d || host.endsWith("." + d));
    if (!ok) return false;
  }

  // per-site override
  if (host in settings.perSite) return settings.perSite[host];

  return settings.enabled;
}

async function broadcastState() {
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});

  for (const tab of tabs) {
    if (await shouldRunOnTab(tab)) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["contentScript.js"]
        });
        chrome.tabs.sendMessage(tab.id, { action: "stateUpdate", settings });
      } catch (e) {
        // Ignore tabs we can't access (e.g., Chrome Web Store)
      }
    } else {
      try {
        chrome.tabs.sendMessage(tab.id, { action: "stop" });
      } catch {}
    }
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get();
  if (!existing || Object.keys(existing).length === 0) {
    await chrome.storage.local.set(DEFAULTS);
  }
  await broadcastState();
});

chrome.storage.onChanged.addListener(() => {
  broadcastState();
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (await shouldRunOnTab(tab)) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["contentScript.js"]
      });
      const settings = await getSettings();
      chrome.tabs.sendMessage(tabId, { action: "stateUpdate", settings });
    } catch {}
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const settings = await getSettings();

    if (message.action === "start") {
      await chrome.storage.local.set({
        enabled: true,
        replacementText: message.replacementText ?? settings.replacementText,
        imageUrl: message.imageUrl ?? settings.imageUrl,
        mode: message.mode ?? settings.mode
      });
      sendResponse({ ok: true });

    } else if (message.action === "stop") {
      await chrome.storage.local.set({ enabled: false });
      sendResponse({ ok: true });

    } else if (message.action === "toggle") {
      await chrome.storage.local.set({ enabled: !settings.enabled });
      sendResponse({ ok: true, enabled: !settings.enabled });

    } else if (message.action === "setPerSite") {
      const tab = sender.tab;
      if (!tab?.url) return sendResponse({ ok: false });
      const host = getHostname(tab.url);
      const perSite = { ...settings.perSite, [host]: message.value };
      await chrome.storage.local.set({ perSite });
      sendResponse({ ok: true });

    } else if (message.action === "getSettings") {
      sendResponse({ ok: true, settings });
    }
  })();

  return true;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle-replacer") {
    const settings = await getSettings();
    await chrome.storage.local.set({ enabled: !settings.enabled });
  }
});
