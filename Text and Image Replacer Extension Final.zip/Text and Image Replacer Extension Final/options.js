const DEFAULTS = {
  enabled: false,
  mode: "both",
  replacementText: "REPLACED",
  imageUrl: "",
  observerEnabled: true,
  preserveInputs: true,
  preserveLinks: true,
  imageFit: "cover",
  whitelist: [],
  blacklist: [],
  perSite: {}
};

function linesToList(text) {
  return text.split("\n").map(s => s.trim()).filter(Boolean);
}
function listToLines(list) {
  return (list || []).join("\n");
}

document.addEventListener("DOMContentLoaded", async () => {
  const enabledEl = document.getElementById("enabled");
  const modeEl = document.getElementById("mode");
  const replacementTextEl = document.getElementById("replacementText");
  const imageFitEl = document.getElementById("imageFit");
  const observerEnabledEl = document.getElementById("observerEnabled");
  const preserveInputsEl = document.getElementById("preserveInputs");
  const preserveLinksEl = document.getElementById("preserveLinks");
  const whitelistEl = document.getElementById("whitelist");
  const blacklistEl = document.getElementById("blacklist");

  const saveSitesBtn = document.getElementById("saveSites");
  const clearPerSiteBtn = document.getElementById("clearPerSite");
  const exportBtn = document.getElementById("exportBtn");
  const importInput = document.getElementById("importInput");
  const resetBtn = document.getElementById("resetBtn");
  const statusEl = document.getElementById("status");

  const stored = await chrome.storage.local.get(DEFAULTS);
  const settings = { ...DEFAULTS, ...stored };

  enabledEl.checked = settings.enabled;
  modeEl.value = settings.mode;
  replacementTextEl.value = settings.replacementText;
  imageFitEl.value = settings.imageFit;
  observerEnabledEl.checked = settings.observerEnabled;
  preserveInputsEl.checked = settings.preserveInputs;
  preserveLinksEl.checked = settings.preserveLinks;
  whitelistEl.value = listToLines(settings.whitelist);
  blacklistEl.value = listToLines(settings.blacklist);

  function saveGeneral() {
    chrome.storage.local.set({
      enabled: enabledEl.checked,
      mode: modeEl.value,
      replacementText: replacementTextEl.value,
      imageFit: imageFitEl.value,
      observerEnabled: observerEnabledEl.checked,
      preserveInputs: preserveInputsEl.checked,
      preserveLinks: preserveLinksEl.checked
    });
    statusEl.textContent = "Saved general settings.";
  }

  enabledEl.addEventListener("change", saveGeneral);
  modeEl.addEventListener("change", saveGeneral);
  replacementTextEl.addEventListener("input", saveGeneral);
  imageFitEl.addEventListener("change", saveGeneral);
  observerEnabledEl.addEventListener("change", saveGeneral);
  preserveInputsEl.addEventListener("change", saveGeneral);
  preserveLinksEl.addEventListener("change", saveGeneral);

  saveSitesBtn.addEventListener("click", async () => {
    await chrome.storage.local.set({
      whitelist: linesToList(whitelistEl.value),
      blacklist: linesToList(blacklistEl.value)
    });
    statusEl.textContent = "Saved site lists.";
  });

  clearPerSiteBtn.addEventListener("click", async () => {
    await chrome.storage.local.set({ perSite: {} });
    statusEl.textContent = "Cleared per-site overrides.";
  });

  exportBtn.addEventListener("click", async () => {
    const all = await chrome.storage.local.get(DEFAULTS);
    const blob = new Blob([JSON.stringify(all, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "text-image-replacer-pro-settings.json";
    a.click();
    URL.revokeObjectURL(url);
    statusEl.textContent = "Exported settings.";
  });

  importInput.addEventListener("change", async () => {
    const file = importInput.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      await chrome.storage.local.set({ ...DEFAULTS, ...data });
      statusEl.textContent = "Imported settings. Reloading page...";
      location.reload();
    } catch {
      statusEl.textContent = "Import failed: invalid JSON.";
    }
  });

  resetBtn.addEventListener("click", async () => {
    await chrome.storage.local.set(DEFAULTS);
    statusEl.textContent = "Reset to defaults. Reloading...";
    location.reload();
  });
});
